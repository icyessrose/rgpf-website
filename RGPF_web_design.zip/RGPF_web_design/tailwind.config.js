
module.exports = {
  content: [
    './pages/**/*.{js,jsx,ts,tsx}',
    './components/**/*.{js,jsx,ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        'rose-800': '#7B2C3B',
        'rose-700': '#9b2f45',
        'gold-500': '#D9A441',
        'gold-400': '#e0b35a',
      }
    },
  },
  plugins: [],
}


RGPF web design - Next.js + Tailwind starter
------------------------------------------

What's included:
- A simple Next.js app (pages-based) with your homepage code in pages/index.jsx
- Tailwind CSS configuration files
- Basic README with setup & deploy instructions

How to run locally:
1. Install Node.js (v18+ recommended)
2. In the project folder run:
   npm install
3. Run the dev server:
   npm run dev
4. Open http://localhost:3000 in your browser

How to deploy:
- Deploy to Vercel (recommended) or Netlify. Connect the repository and Vercel will handle the build.
- Ensure the install command runs `npm install` and build command is `npm run build`.

Notes:
- This is a starter scaffold. It uses Tailwind classes in the JSX; you must install dependencies to run.
- Update contact info and all placeholders in pages/index.jsx before going live.
